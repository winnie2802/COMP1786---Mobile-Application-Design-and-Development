package com.example.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.constraintlayout.widget.ConstraintLayout;

public class AddTaskActivity extends AppCompatActivity {

    private EditText taskNameInput;
    private EditText taskDescriptionInput;
    private int position = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        // Initialize UI components
        ConstraintLayout rootLayout = findViewById(R.id.rootLayout);
        taskNameInput = findViewById(R.id.taskNameInput);
        taskDescriptionInput = findViewById(R.id.taskDescriptionInput);
        Button saveButton = findViewById(R.id.saveButton);

        // Handle system insets to avoid status bar and camera cutout
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
            int topInset = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int cutoutInset = insets.getInsets(WindowInsetsCompat.Type.displayCutout()).top;
            v.setPadding(v.getPaddingLeft(), topInset + cutoutInset, v.getPaddingRight(), v.getPaddingBottom());
            return insets;
        });

        // Check if editing an existing task
        Intent intent = getIntent();
        if (intent.hasExtra("task_name")) {
            taskNameInput.setText(intent.getStringExtra("task_name"));
            taskDescriptionInput.setText(intent.getStringExtra("task_description"));
            position = intent.getIntExtra("position", -1);
        }

        // Handle save button click
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taskName = taskNameInput.getText().toString().trim();
                String taskDescription = taskDescriptionInput.getText().toString().trim();
                if (taskName.isEmpty()) {
                    Toast.makeText(AddTaskActivity.this, "Task name cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent resultIntent = new Intent();
                resultIntent.putExtra("task_name", taskName);
                resultIntent.putExtra("task_description", taskDescription);
                if (position != -1) {
                    resultIntent.putExtra("position", position);
                }
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}