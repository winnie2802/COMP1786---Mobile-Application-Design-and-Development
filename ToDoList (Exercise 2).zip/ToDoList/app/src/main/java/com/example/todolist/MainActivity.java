package com.example.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Task> taskList;
    private TaskAdapter taskAdapter;
    private static final int ADD_TASK_REQUEST = 1;
    private static final int EDIT_TASK_REQUEST = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        ConstraintLayout rootLayout = findViewById(R.id.rootLayout);
        RecyclerView taskRecyclerView = findViewById(R.id.taskRecyclerView);
        Button addTaskButton = findViewById(R.id.addTaskButton);

        // Handle system insets to avoid status bar and camera cutout
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
            int topInset = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int cutoutInset = insets.getInsets(WindowInsetsCompat.Type.displayCutout()).top;
            v.setPadding(v.getPaddingLeft(), topInset + cutoutInset, v.getPaddingRight(), v.getPaddingBottom());
            return insets;
        });

        // Initialize task list and adapter
        taskList = new ArrayList<>();
        taskAdapter = new TaskAdapter(taskList, new TaskAdapter.OnTaskClickListener() {
            @Override
            public void onEditClick(int position) {
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                intent.putExtra("task_name", taskList.get(position).getName());
                intent.putExtra("task_description", taskList.get(position).getDescription());
                intent.putExtra("position", position);
                startActivityForResult(intent, EDIT_TASK_REQUEST);
            }

            @Override
            public void onDeleteClick(int position) {
                taskList.remove(position);
                taskAdapter.notifyItemRemoved(position);
            }
        });
        taskRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        taskRecyclerView.setAdapter(taskAdapter);

        // Handle add task button click
        addTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivityForResult(intent, ADD_TASK_REQUEST);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            String taskName = data.getStringExtra("task_name");
            String taskDescription = data.getStringExtra("task_description");
            if (requestCode == ADD_TASK_REQUEST) {
                taskList.add(new Task(taskName, taskDescription));
                taskAdapter.notifyItemInserted(taskList.size() - 1);
            } else if (requestCode == EDIT_TASK_REQUEST) {
                int position = data.getIntExtra("position", -1);
                if (position != -1) {
                    taskList.get(position).setName(taskName);
                    taskList.get(position).setDescription(taskDescription);
                    taskAdapter.notifyItemChanged(position);
                }
            }
        }
    }
}