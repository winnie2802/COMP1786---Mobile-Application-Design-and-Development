package com.example.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.constraintlayout.widget.ConstraintLayout;

public class AddTaskActivity extends AppCompatActivity {

    private EditText taskNameInput;
    private EditText taskDescriptionInput;
    private Spinner completedStatusSpinner;
    private int position = -1;
    private int taskId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        // Initialize UI components
        ConstraintLayout rootLayout = findViewById(R.id.rootLayout);
        taskNameInput = findViewById(R.id.taskNameInput);
        taskDescriptionInput = findViewById(R.id.taskDescriptionInput);
        completedStatusSpinner = findViewById(R.id.completedStatusSpinner);
        Button saveButton = findViewById(R.id.saveButton);

        // Setup Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.completion_statuses, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        completedStatusSpinner.setAdapter(adapter);

        // Handle system insets to avoid status bar and camera cutout
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
            int topInset = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int cutoutInset = insets.getInsets(WindowInsetsCompat.Type.displayCutout()).top;
            v.setPadding(v.getPaddingLeft(), topInset + cutoutInset, v.getPaddingRight(), v.getPaddingBottom());
            return insets;
        });

        // Check if editing an existing task
        Intent intent = getIntent();
        if (intent.hasExtra("task_name")) {
            taskNameInput.setText(intent.getStringExtra("task_name"));
            taskDescriptionInput.setText(intent.getStringExtra("task_description"));
            position = intent.getIntExtra("position", -1);
            taskId = intent.getIntExtra("task_id", -1);
            int completedStatus = intent.getIntExtra("completed_status", 0);
            completedStatusSpinner.setSelection(completedStatus / 25);
            completedStatusSpinner.setEnabled(true); // Enable Spinner for editing
        } else {
            completedStatusSpinner.setSelection(0); // Ensure 0% for new tasks
            completedStatusSpinner.setEnabled(false); // Disable Spinner for new tasks
        }

        // Handle save button click
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taskName = taskNameInput.getText().toString().trim();
                String taskDescription = taskDescriptionInput.getText().toString().trim();
                int completedStatus = intent.hasExtra("task_name") ? completedStatusSpinner.getSelectedItemPosition() * 25 : 0;

                if (taskName.isEmpty()) {
                    Toast.makeText(AddTaskActivity.this, "Task name cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                Intent resultIntent = new Intent();
                resultIntent.putExtra("task_name", taskName);
                resultIntent.putExtra("task_description", taskDescription);
                resultIntent.putExtra("completed_status", completedStatus);
                resultIntent.putExtra("position", position);
                resultIntent.putExtra("task_id", taskId);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }
}