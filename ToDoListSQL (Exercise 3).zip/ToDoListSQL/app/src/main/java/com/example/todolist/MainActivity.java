package com.example.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Task> taskList;
    private TaskAdapter taskAdapter;
    private DatabaseHelper dbHelper;
    private static final int ADD_TASK_REQUEST = 1;
    private static final int EDIT_TASK_REQUEST = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        ConstraintLayout rootLayout = findViewById(R.id.rootLayout);
        RecyclerView taskRecyclerView = findViewById(R.id.taskRecyclerView);
        Button addTaskButton = findViewById(R.id.addTaskButton);

        // Handle system insets to avoid status bar and camera cutout
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
            int topInset = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int cutoutInset = insets.getInsets(WindowInsetsCompat.Type.displayCutout()).top;
            v.setPadding(v.getPaddingLeft(), topInset + cutoutInset, v.getPaddingRight(), v.getPaddingBottom());
            return insets;
        });

        // Initialize database and task list
        dbHelper = new DatabaseHelper(this);
        taskList = new ArrayList<>();
        loadTasks();

        // Initialize adapter
        taskAdapter = new TaskAdapter(taskList, new TaskAdapter.OnTaskClickListener() {
            @Override
            public void onEditClick(int position) {
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                intent.putExtra("task_id", taskList.get(position).getId());
                intent.putExtra("task_name", taskList.get(position).getName());
                intent.putExtra("task_description", taskList.get(position).getDescription());
                intent.putExtra("completed_status", taskList.get(position).getCompletedStatus());
                intent.putExtra("position", position);
                startActivityForResult(intent, EDIT_TASK_REQUEST);
            }

            @Override
            public void onDeleteClick(int position) {
                int taskId = taskList.get(position).getId();
                if (dbHelper.deleteTask(taskId)) {
                    taskList.remove(position);
                    taskAdapter.notifyItemRemoved(position);
                } else {
                    Toast.makeText(MainActivity.this, "Failed to delete task", Toast.LENGTH_SHORT).show();
                }
            }
        });
        taskRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        taskRecyclerView.setAdapter(taskAdapter);

        // Handle add task button click
        addTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivityForResult(intent, ADD_TASK_REQUEST);
            }
        });
    }

    private void loadTasks() {
        taskList.clear();
        taskList.addAll(dbHelper.getAllTasks());
        if (taskAdapter != null) {
            taskAdapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            String taskName = data.getStringExtra("task_name");
            String taskDescription = data.getStringExtra("task_description");
            int completedStatus = data.getIntExtra("completed_status", 0);

            if (requestCode == ADD_TASK_REQUEST) {
                Task newTask = new Task(taskName, taskDescription);
                newTask.setCompletedStatus(completedStatus); // Should always be 0 for new tasks
                if (dbHelper.addTask(newTask)) {
                    loadTasks();
                } else {
                    Toast.makeText(this, "Failed to add task", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == EDIT_TASK_REQUEST) {
                int position = data.getIntExtra("position", -1);
                int taskId = data.getIntExtra("task_id", -1);
                if (position != -1 && taskId != -1) {
                    Task updatedTask = new Task(taskName, taskDescription);
                    updatedTask.setId(taskId);
                    updatedTask.setCompletedStatus(completedStatus);
                    if (dbHelper.updateTask(updatedTask)) {
                        loadTasks();
                    } else {
                        Toast.makeText(this, "Failed to update task", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }
}