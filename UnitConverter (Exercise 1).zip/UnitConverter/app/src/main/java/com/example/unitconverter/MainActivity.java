package com.example.unitconverter;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private Spinner fromUnitSpinner;
    private Spinner toUnitSpinner;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        inputValue = findViewById(R.id.inputValue);
        fromUnitSpinner = findViewById(R.id.fromUnitSpinner);
        toUnitSpinner = findViewById(R.id.toUnitSpinner);
        Button convertButton = findViewById(R.id.convertButton);
        resultText = findViewById(R.id.resultText);
        ConstraintLayout rootLayout = findViewById(R.id.rootLayout);

        // Handle system insets to avoid status bar and camera cutout
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
            int topInset = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int cutoutInset = insets.getInsets(WindowInsetsCompat.Type.displayCutout()).top;
            v.setPadding(v.getPaddingLeft(), topInset + cutoutInset, v.getPaddingRight(), v.getPaddingBottom());
            return insets;
        });

        // Set up spinners with length units
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.length_units,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromUnitSpinner.setAdapter(adapter);
        toUnitSpinner.setAdapter(adapter);

        // Handle convert button click
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = inputValue.getText().toString();

                // Validate input
                if (inputText.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a value", Toast.LENGTH_SHORT).show();
                    return;
                }

                double value;
                try {
                    value = Double.parseDouble(inputText);
                    if (value < 0) {
                        Toast.makeText(MainActivity.this, "Value cannot be negative", Toast.LENGTH_SHORT).show();
                        return;
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Invalid number format", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Get selected units
                String fromUnit = fromUnitSpinner.getSelectedItem().toString();
                String toUnit = toUnitSpinner.getSelectedItem().toString();

                // Perform conversion
                double result = convertLength(value, fromUnit, toUnit);

                // Display result in format: (Entered value) (first unit) = (result) (second unit)
                resultText.setText(String.format("%s %s = %.4f %s", inputText, fromUnit, result, toUnit));
            }
        });
    }

    private double convertLength(double value, String fromUnit, String toUnit) {
        // Convert input to metres first
        double valueInMetres;
        switch (fromUnit) {
            case "Metre":
                valueInMetres = value;
                break;
            case "Millimetre":
                valueInMetres = value / 1000;
                break;
            case "Mile":
                valueInMetres = value * 1609.344;
                break;
            case "Foot":
                valueInMetres = value * 0.3048;
                break;
            default:
                valueInMetres = value;
        }

        // Convert from metres to target unit
        switch (toUnit) {
            case "Metre":
                return valueInMetres;
            case "Millimetre":
                return valueInMetres * 1000;
            case "Mile":
                return valueInMetres / 1609.344;
            case "Foot":
                return valueInMetres / 0.3048;
            default:
                return valueInMetres;
        }
    }
}