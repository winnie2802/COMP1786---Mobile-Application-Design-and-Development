package com.example.universalyogaadminapp;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import java.util.Calendar;

public class AddClassActivity extends AppCompatActivity {
    private EditText editTextTimeOfCourse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_class);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Add Class");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Set up Day of the Week Spinner
        Spinner spinnerDayOfWeek = findViewById(R.id.spinnerDayOfWeek);
        ArrayAdapter<CharSequence> dayAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.days_of_week,
                android.R.layout.simple_spinner_item
        );
        dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDayOfWeek.setAdapter(dayAdapter);

        // Set up Time of Course TimePicker
        editTextTimeOfCourse = findViewById(R.id.editTextTimeOfCourse);
        editTextTimeOfCourse.setKeyListener(null); // Prevent manual text input
        editTextTimeOfCourse.setOnClickListener(v -> showTimePickerDialog());
        editTextTimeOfCourse.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                showTimePickerDialog();
            }
        });

        // Set up Duration Spinner
        Spinner spinnerDuration = findViewById(R.id.spinnerDuration);
        ArrayAdapter<CharSequence> durationAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.durations,
                android.R.layout.simple_spinner_item
        );
        durationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDuration.setAdapter(durationAdapter);

        // Set up Add Button
        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(v -> {
            // Collect form data
            String dayOfWeek = spinnerDayOfWeek.getSelectedItem() != null ? spinnerDayOfWeek.getSelectedItem().toString() : "";
            String timeOfCourse = editTextTimeOfCourse.getText().toString();
            String capacityStr = ((EditText) findViewById(R.id.editTextCapacity)).getText().toString();
            String duration = spinnerDuration.getSelectedItem() != null ? spinnerDuration.getSelectedItem().toString() : "";
            String priceStr = ((EditText) findViewById(R.id.editTextPrice)).getText().toString();
            String description = ((EditText) findViewById(R.id.editTextDescription)).getText().toString();

            // Validate required fields
            ArrayList<String> missingFields = new ArrayList<>();
            if (dayOfWeek.isEmpty()) {
                missingFields.add("Day of the Week");
            }
            if (timeOfCourse.isEmpty()) {
                missingFields.add("Time of Course");
            }
            if (capacityStr.isEmpty()) {
                missingFields.add("Capacity");
            }
            if (duration.isEmpty()) {
                missingFields.add("Duration");
            }
            if (priceStr.isEmpty()) {
                missingFields.add("Price per Class");
            }

            // Display error or proceed
            if (!missingFields.isEmpty()) {
                String errorMessage = "Please fill in: " + String.join(", ", missingFields);
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
            } else {
                // Parse capacity and price
                int capacity;
                double price;
                try {
                    capacity = Integer.parseInt(capacityStr);
                    price = Double.parseDouble(priceStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid number format for Capacity or Price", Toast.LENGTH_LONG).show();
                    return;
                }

                // Return data to ClassesManagementActivity
                Intent resultIntent = new Intent();
                resultIntent.putExtra("dayOfWeek", dayOfWeek);
                resultIntent.putExtra("timeOfCourse", timeOfCourse);
                resultIntent.putExtra("capacity", capacity);
                resultIntent.putExtra("duration", duration);
                resultIntent.putExtra("price", price);
                resultIntent.putExtra("description", description);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }

    private void showTimePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minuteOfHour) -> {
                    Calendar selectedTime = Calendar.getInstance();
                    selectedTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    selectedTime.set(Calendar.MINUTE, minuteOfHour);
                    String time = DateFormat.format("hh:mm a", selectedTime).toString();
                    editTextTimeOfCourse.setText(time);
                },
                hour,
                minute,
                false // false for AM/PM, true for 24-hour
        );
        timePickerDialog.show();
    }
}