package com.example.universalyogaadminapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import java.util.Calendar;

public class AddScheduleActivity extends AppCompatActivity {
    private static final String TAG = "AddScheduleActivity";
    private EditText editTextDate, editTextTeacher, editTextComments;
    private String dayOfWeek;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_schedule);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Add Schedule");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Get day of week from Intent
        dayOfWeek = getIntent().getStringExtra("dayOfWeek");
        Log.d(TAG, "Received dayOfWeek=" + dayOfWeek);

        // Initialize UI elements
        editTextDate = findViewById(R.id.editTextDate);
        editTextTeacher = findViewById(R.id.editTextTeacher);
        editTextComments = findViewById(R.id.editTextComments);
        Button btnAdd = findViewById(R.id.btnAdd);

        // Set up Date Picker
        editTextDate.setKeyListener(null);
        editTextDate.setOnClickListener(v -> showDatePickerDialog());
        editTextDate.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) showDatePickerDialog();
        });

        // Add button click
        btnAdd.setOnClickListener(v -> {
            String date = editTextDate.getText().toString().trim();
            String teacher = editTextTeacher.getText().toString().trim();
            String comments = editTextComments.getText().toString().trim();

            Log.d(TAG, "Add clicked: date=" + date + ", teacher=" + teacher + ", comments=" + comments);

            // Validate inputs
            ArrayList<String> missingFields = new ArrayList<>();
            if (date.isEmpty()) missingFields.add("Date");
            if (teacher.isEmpty()) missingFields.add("Teacher");

            if (!missingFields.isEmpty()) {
                String errorMessage = "Please fill in: " + String.join(", ", missingFields);
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
                Log.w(TAG, "Validation failed: " + errorMessage);
                return;
            }

            // Return data
            Intent resultIntent = new Intent();
            resultIntent.putExtra("date", date);
            resultIntent.putExtra("teacher", teacher);
            resultIntent.putExtra("comments", comments);
            setResult(RESULT_OK, resultIntent);
            Log.d(TAG, "Returning result");
            finish();
        });
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        RestrictedDatePickerDialog datePickerDialog = new RestrictedDatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(selectedYear, selectedMonth, selectedDay);
                    String date = DateFormat.format("dd/MM/yyyy", selectedDate).toString();
                    editTextDate.setText(date);
                    Log.d(TAG, "Date selected: " + date);
                },
                year, month, day, dayOfWeek);
        datePickerDialog.show();
    }
}