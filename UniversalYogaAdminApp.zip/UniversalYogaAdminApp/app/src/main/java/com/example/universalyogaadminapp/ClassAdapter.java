package com.example.universalyogaadminapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ClassAdapter extends RecyclerView.Adapter<ClassAdapter.ClassViewHolder> {
    private List<YogaClass> classList;
    private OnClassActionListener listener;

    public interface OnClassActionListener {
        void onEdit(int position);
        void onDelete(int position);
        void onShowSchedules(int position);
    }

    public ClassAdapter(List<YogaClass> classList, OnClassActionListener listener) {
        this.classList = classList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ClassViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_class, parent, false);
        return new ClassViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ClassViewHolder holder, int position) {
        YogaClass yogaClass = classList.get(position);
        holder.textViewDayOfWeek.setText("Day of the Week: " + yogaClass.getDayOfWeek());
        holder.textViewTimeOfCourse.setText("Time of Course: " + yogaClass.getTimeOfCourse());
        holder.textViewCapacity.setText("Capacity: " + yogaClass.getCapacity());
        holder.textViewDuration.setText("Duration: " + yogaClass.getDuration());
        holder.textViewPrice.setText("Price per Class: £" + String.format("%.2f", yogaClass.getPrice()));
        holder.textViewDescription.setText("Description: " + (yogaClass.getDescription().isEmpty() ? "None" : yogaClass.getDescription()));

        holder.btnEdit.setOnClickListener(v -> listener.onEdit(position));
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(position));
        holder.btnShowSchedules.setOnClickListener(v -> listener.onShowSchedules(position));
    }

    @Override
    public int getItemCount() {
        return classList.size();
    }

    static class ClassViewHolder extends RecyclerView.ViewHolder {
        TextView textViewDayOfWeek;
        TextView textViewTimeOfCourse;
        TextView textViewCapacity;
        TextView textViewDuration;
        TextView textViewPrice;
        TextView textViewDescription;
        com.google.android.material.button.MaterialButton btnEdit;
        com.google.android.material.button.MaterialButton btnDelete;
        com.google.android.material.button.MaterialButton btnShowSchedules;

        public ClassViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewDayOfWeek = itemView.findViewById(R.id.textViewDayOfWeek);
            textViewTimeOfCourse = itemView.findViewById(R.id.textViewTimeOfCourse);
            textViewCapacity = itemView.findViewById(R.id.textViewCapacity);
            textViewDuration = itemView.findViewById(R.id.textViewDuration);
            textViewPrice = itemView.findViewById(R.id.textViewPrice);
            textViewDescription = itemView.findViewById(R.id.textViewDescription);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnShowSchedules = itemView.findViewById(R.id.btnShowSchedules);
        }
    }
}