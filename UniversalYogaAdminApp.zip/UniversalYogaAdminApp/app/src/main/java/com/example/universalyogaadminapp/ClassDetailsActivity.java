package com.example.universalyogaadminapp;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;

public class ClassDetailsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_details);

        // Set up Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Class Details");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Get class data from Intent
        String dayOfWeek = getIntent().getStringExtra("dayOfWeek");
        String timeOfCourse = getIntent().getStringExtra("timeOfCourse");
        int capacity = getIntent().getIntExtra("capacity", 0);
        String duration = getIntent().getStringExtra("duration");
        double price = getIntent().getDoubleExtra("price", 0.0);
        String description = getIntent().getStringExtra("description");
        ArrayList<String> schedules = getIntent().getStringArrayListExtra("schedules");

        // Set up TextViews
        TextView textViewDayOfWeek = findViewById(R.id.textViewDayOfWeek);
        TextView textViewTimeOfCourse = findViewById(R.id.textViewTimeOfCourse);
        TextView textViewCapacity = findViewById(R.id.textViewCapacity);
        TextView textViewDuration = findViewById(R.id.textViewDuration);
        TextView textViewPrice = findViewById(R.id.textViewPrice);
        TextView textViewDescription = findViewById(R.id.textViewDescription);
        TextView textViewSchedules = findViewById(R.id.textViewSchedules);

        textViewDayOfWeek.setText("Day of the Week: " + dayOfWeek);
        textViewTimeOfCourse.setText("Time of Course: " + timeOfCourse);
        textViewCapacity.setText("Capacity: " + capacity);
        textViewDuration.setText("Duration: " + duration);
        textViewPrice.setText("Price per Class: £" + String.format("%.2f", price));
        textViewDescription.setText("Description: " + (description.isEmpty() ? "None" : description));
        textViewSchedules.setText("Schedules:\n" + (schedules.isEmpty() ? "None" : String.join("\n", schedules)));
    }
}