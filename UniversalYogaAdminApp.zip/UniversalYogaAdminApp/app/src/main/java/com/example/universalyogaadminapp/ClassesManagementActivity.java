package com.example.universalyogaadminapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ClassesManagementActivity extends AppCompatActivity implements ClassAdapter.OnClassActionListener {
    private static final int REQUEST_ADD_CLASS = 1;
    private static final int REQUEST_EDIT_CLASS = 2;
    private List<YogaClass> classList;
    private ClassAdapter classAdapter;
    private YogaDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classes_management);

        // Initialize database helper
        dbHelper = new YogaDatabaseHelper(this);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Classes Management");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Initialize class list and RecyclerView
        classList = new ArrayList<>();
        classList.addAll(dbHelper.getAllClasses()); // Load from database
        RecyclerView recyclerViewClasses = findViewById(R.id.recyclerViewClasses);
        recyclerViewClasses.setLayoutManager(new LinearLayoutManager(this));
        classAdapter = new ClassAdapter(classList, this);
        recyclerViewClasses.setAdapter(classAdapter);

        // Set up Add Class Button
        findViewById(R.id.btnAddClass).setOnClickListener(v -> {
            Intent intent = new Intent(ClassesManagementActivity.this, AddClassActivity.class);
            startActivityForResult(intent, REQUEST_ADD_CLASS);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == REQUEST_ADD_CLASS) {
                String dayOfWeek = data.getStringExtra("dayOfWeek");
                String timeOfCourse = data.getStringExtra("timeOfCourse");
                int capacity = data.getIntExtra("capacity", 0);
                String duration = data.getStringExtra("duration");
                double price = data.getDoubleExtra("price", 0.0);
                String description = data.getStringExtra("description");

                YogaClass yogaClass = new YogaClass(dayOfWeek, timeOfCourse, capacity, duration, price, description);
                long classId = dbHelper.addClass(yogaClass); // Save to database
                if (classId != -1) {
                    classList.clear();
                    classList.addAll(dbHelper.getAllClasses());
                    classAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(this, "Failed to add class", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == REQUEST_EDIT_CLASS) {
                int position = data.getIntExtra("classPosition", -1);
                if (position >= 0 && position < classList.size()) {
                    String dayOfWeek = data.getStringExtra("dayOfWeek");
                    String timeOfCourse = data.getStringExtra("timeOfCourse");
                    int capacity = data.getIntExtra("capacity", 0);
                    String duration = data.getStringExtra("duration");
                    double price = data.getDoubleExtra("price", 0.0);
                    String description = data.getStringExtra("description");

                    YogaClass updatedClass = new YogaClass(dayOfWeek, timeOfCourse, capacity, duration, price, description);
                    long classId = dbHelper.getClassIdByPosition(position);
                    if (classId != -1) {
                        dbHelper.updateClass(classId, updatedClass); // Update in database
                        classList.clear();
                        classList.addAll(dbHelper.getAllClasses());
                        classAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(this, "Failed to find class ID", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }

    @Override
    public void onEdit(int position) {
        YogaClass yogaClass = classList.get(position);
        Intent intent = new Intent(this, EditClassActivity.class);
        intent.putExtra("classPosition", position);
        intent.putExtra("dayOfWeek", yogaClass.getDayOfWeek());
        intent.putExtra("timeOfCourse", yogaClass.getTimeOfCourse());
        intent.putExtra("capacity", yogaClass.getCapacity());
        intent.putExtra("duration", yogaClass.getDuration());
        intent.putExtra("price", yogaClass.getPrice());
        intent.putExtra("description", yogaClass.getDescription());
        startActivityForResult(intent, REQUEST_EDIT_CLASS);
    }

    @Override
    public void onDelete(int position) {
        // Show confirmation dialog
        new AlertDialog.Builder(this)
                .setTitle("Delete Class")
                .setMessage("Are you sure you want to delete this class? This will also delete all associated schedules.")
                .setPositiveButton("Yes", (dialog, which) -> {
                    long classId = dbHelper.getClassIdByPosition(position);
                    if (classId != -1) {
                        dbHelper.deleteClass(classId); // Delete from database and Firebase
                        classList.clear();
                        classList.addAll(dbHelper.getAllClasses());
                        classAdapter.notifyDataSetChanged();
                        Toast.makeText(this, "Class deleted successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to find class ID", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                .setCancelable(true)
                .show();
    }

    @Override
    public void onShowSchedules(int position) {
        long classId = dbHelper.getClassIdByPosition(position);
        if (classId != -1) {
            Intent intent = new Intent(this, SchedulesManagementActivity.class);
            intent.putExtra("classIndex", position);
            intent.putExtra("dayOfWeek", classList.get(position).getDayOfWeek());
            intent.putExtra("classId", classId); // Pass classId for SchedulesManagementActivity
            startActivity(intent);
        } else {
            Toast.makeText(this, "Failed to find class ID", Toast.LENGTH_SHORT).show();
        }
    }
}