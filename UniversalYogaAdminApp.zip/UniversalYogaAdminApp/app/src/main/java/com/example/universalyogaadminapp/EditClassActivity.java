package com.example.universalyogaadminapp;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;

public class EditClassActivity extends AppCompatActivity {
    private EditText editTextTimeOfCourse;
    private int classPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_class);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Edit Class");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Get class data from Intent
        Intent intent = getIntent();
        classPosition = intent.getIntExtra("classPosition", -1);
        String dayOfWeek = intent.getStringExtra("dayOfWeek");
        String timeOfCourse = intent.getStringExtra("timeOfCourse");
        int capacity = intent.getIntExtra("capacity", 0);
        String duration = intent.getStringExtra("duration");
        double price = intent.getDoubleExtra("price", 0.0);
        String description = intent.getStringExtra("description");

        // Set up Day of the Week Spinner (non-editable)
        Spinner spinnerDayOfWeek = findViewById(R.id.spinnerDayOfWeek);
        ArrayAdapter<CharSequence> dayAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.days_of_week,
                android.R.layout.simple_spinner_item
        );
        dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDayOfWeek.setAdapter(dayAdapter);
        if (dayOfWeek != null) {
            int dayPosition = Arrays.asList(getResources().getStringArray(R.array.days_of_week)).indexOf(dayOfWeek);
            spinnerDayOfWeek.setSelection(dayPosition);
        }
        spinnerDayOfWeek.setEnabled(false); // Reinforce non-editable state programmatically

        // Set up Time of Course TimePicker
        editTextTimeOfCourse = findViewById(R.id.editTextTimeOfCourse);
        editTextTimeOfCourse.setKeyListener(null); // Prevent manual text input
        editTextTimeOfCourse.setText(timeOfCourse);
        editTextTimeOfCourse.setOnClickListener(v -> showTimePickerDialog());
        editTextTimeOfCourse.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                showTimePickerDialog();
            }
        });

        // Set up Capacity
        EditText editTextCapacity = findViewById(R.id.editTextCapacity);
        editTextCapacity.setText(String.valueOf(capacity));

        // Set up Duration Spinner
        Spinner spinnerDuration = findViewById(R.id.spinnerDuration);
        ArrayAdapter<CharSequence> durationAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.durations,
                android.R.layout.simple_spinner_item
        );
        durationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDuration.setAdapter(durationAdapter);
        if (duration != null) {
            int durationPosition = Arrays.asList(getResources().getStringArray(R.array.durations)).indexOf(duration);
            spinnerDuration.setSelection(durationPosition);
        }

        // Set up Price
        EditText editTextPrice = findViewById(R.id.editTextPrice);
        editTextPrice.setText(String.format("%.2f", price));

        // Set up Description
        EditText editTextDescription = findViewById(R.id.editTextDescription);
        editTextDescription.setText(description);

        // Set up Update Button
        Button btnUpdate = findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(v -> {
            // Collect form data
            String updatedDayOfWeek = dayOfWeek; // Use original dayOfWeek, as Spinner is disabled
            String updatedTimeOfCourse = editTextTimeOfCourse.getText().toString();
            String updatedCapacityStr = editTextCapacity.getText().toString();
            String updatedDuration = spinnerDuration.getSelectedItem() != null ? spinnerDuration.getSelectedItem().toString() : "";
            String updatedPriceStr = editTextPrice.getText().toString();
            String updatedDescription = editTextDescription.getText().toString();

            // Validate required fields
            ArrayList<String> missingFields = new ArrayList<>();
            if (updatedTimeOfCourse.isEmpty()) {
                missingFields.add("Time of Course");
            }
            if (updatedCapacityStr.isEmpty()) {
                missingFields.add("Capacity");
            }
            if (updatedDuration.isEmpty()) {
                missingFields.add("Duration");
            }
            if (updatedPriceStr.isEmpty()) {
                missingFields.add("Price per Class");
            }

            // Display error or proceed
            if (!missingFields.isEmpty()) {
                String errorMessage = "Please fill in: " + String.join(", ", missingFields);
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
            } else {
                // Parse capacity and price
                int updatedCapacity;
                double updatedPrice;
                try {
                    updatedCapacity = Integer.parseInt(updatedCapacityStr);
                    updatedPrice = Double.parseDouble(updatedPriceStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid number format for Capacity or Price", Toast.LENGTH_LONG).show();
                    return;
                }

                // Return updated data to ClassesManagementActivity
                Intent resultIntent = new Intent();
                resultIntent.putExtra("classPosition", classPosition);
                resultIntent.putExtra("dayOfWeek", updatedDayOfWeek);
                resultIntent.putExtra("timeOfCourse", updatedTimeOfCourse);
                resultIntent.putExtra("capacity", updatedCapacity);
                resultIntent.putExtra("duration", updatedDuration);
                resultIntent.putExtra("price", updatedPrice);
                resultIntent.putExtra("description", updatedDescription);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }

    private void showTimePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minuteOfHour) -> {
                    Calendar selectedTime = Calendar.getInstance();
                    selectedTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    selectedTime.set(Calendar.MINUTE, minuteOfHour);
                    String time = DateFormat.format("hh:mm a", selectedTime).toString();
                    editTextTimeOfCourse.setText(time);
                },
                hour,
                minute,
                false // false for AM/PM, true for 24-hour
        );
        timePickerDialog.show();
    }
}