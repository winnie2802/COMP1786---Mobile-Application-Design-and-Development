package com.example.universalyogaadminapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;
import java.util.Calendar;

public class EditScheduleActivity extends AppCompatActivity {
    private static final String TAG = "EditScheduleActivity";
    private EditText editTextDate, editTextTeacher, editTextComments;
    private String dayOfWeek;
    private int schedulePosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_schedule);

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Edit Schedule");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Get schedule data from Intent
        Intent intent = getIntent();
        schedulePosition = intent.getIntExtra("schedulePosition", -1);
        String date = intent.getStringExtra("date");
        String teacher = intent.getStringExtra("teacher");
        String comments = intent.getStringExtra("comments");
        dayOfWeek = intent.getStringExtra("dayOfWeek");

        Log.d(TAG, "Received data: position=" + schedulePosition + ", date=" + date + ", teacher=" + teacher + ", comments=" + comments + ", dayOfWeek=" + dayOfWeek);

        // Initialize UI elements
        editTextDate = findViewById(R.id.editTextDate);
        editTextTeacher = findViewById(R.id.editTextTeacher);
        editTextComments = findViewById(R.id.editTextComments);
        Button btnUpdate = findViewById(R.id.btnUpdate);

        // Set existing values
        editTextDate.setText(date);
        editTextTeacher.setText(teacher);
        editTextComments.setText(comments);

        // Set up Date Picker
        editTextDate.setKeyListener(null);
        editTextDate.setOnClickListener(v -> showDatePickerDialog());
        editTextDate.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) showDatePickerDialog();
        });

        // Update button click
        btnUpdate.setOnClickListener(v -> {
            String updatedDate = editTextDate.getText().toString().trim();
            String updatedTeacher = editTextTeacher.getText().toString().trim();
            String updatedComments = editTextComments.getText().toString().trim();

            Log.d(TAG, "Update clicked: date=" + updatedDate + ", teacher=" + updatedTeacher + ", comments=" + updatedComments);

            // Validate inputs
            ArrayList<String> missingFields = new ArrayList<>();
            if (updatedDate.isEmpty()) missingFields.add("Date");
            if (updatedTeacher.isEmpty()) missingFields.add("Teacher");

            if (!missingFields.isEmpty()) {
                String errorMessage = "Please fill in: " + String.join(", ", missingFields);
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
                Log.w(TAG, "Validation failed: " + errorMessage);
                return;
            }

            // Return updated data
            Intent resultIntent = new Intent();
            resultIntent.putExtra("schedulePosition", schedulePosition);
            resultIntent.putExtra("date", updatedDate);
            resultIntent.putExtra("teacher", updatedTeacher);
            resultIntent.putExtra("comments", updatedComments);
            setResult(RESULT_OK, resultIntent);
            Log.d(TAG, "Returning result: position=" + schedulePosition);
            finish();
        });
    }

    private void showDatePickerDialog() {
        // Initialize with a valid future date
        Calendar calendar = Calendar.getInstance();
        String currentDate = editTextDate.getText().toString().trim();
        if (!currentDate.isEmpty()) {
            try {
                String[] dateParts = currentDate.split("/");
                calendar.set(Integer.parseInt(dateParts[2]), Integer.parseInt(dateParts[1]) - 1, Integer.parseInt(dateParts[0]));
            } catch (Exception e) {
                Log.w(TAG, "Invalid date format: " + currentDate);
            }
        }
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        RestrictedDatePickerDialog datePickerDialog = new RestrictedDatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(selectedYear, selectedMonth, selectedDay);
                    String date = DateFormat.format("dd/MM/yyyy", selectedDate).toString();
                    editTextDate.setText(date);
                    Log.d(TAG, "Date selected: " + date);
                },
                year, month, day, dayOfWeek);
        datePickerDialog.show();
    }
}