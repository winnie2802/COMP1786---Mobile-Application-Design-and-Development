package com.example.universalyogaadminapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase
        FirebaseDatabase.getInstance().setPersistenceEnabled(true); // Enable offline support

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Universal Yoga Admin");
        }

        // Set up buttons
        Button btnClassesManagement = findViewById(R.id.btnClassesManagement);
        Button btnSearch = findViewById(R.id.btnSearch);

        btnClassesManagement.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ClassesManagementActivity.class);
            startActivity(intent);
        });

        btnSearch.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SearchActivity.class);
            startActivity(intent);
        });
    }
}