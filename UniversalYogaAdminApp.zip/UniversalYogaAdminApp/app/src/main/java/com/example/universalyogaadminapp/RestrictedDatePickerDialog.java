package com.example.universalyogaadminapp;

import android.app.DatePickerDialog;
import android.content.Context;
import android.util.Log;
import android.widget.DatePicker;
import java.util.Arrays;
import java.util.Calendar;

public class RestrictedDatePickerDialog extends DatePickerDialog {
    private static final String TAG = "RestrictedDatePicker";
    private static final String[] DAYS_OF_WEEK = {
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
    };
    private String targetDayOfWeek;

    public RestrictedDatePickerDialog(Context context, OnDateSetListener listener, int year, int month, int day, String targetDayOfWeek) {
        super(context, listener, year, month, day);
        this.targetDayOfWeek = targetDayOfWeek;

        // Set minimum date to today
        Calendar today = Calendar.getInstance();
        getDatePicker().setMinDate(today.getTimeInMillis());

        restrictToDayOfWeek();
    }

    private void restrictToDayOfWeek() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(getDatePicker().getYear(), getDatePicker().getMonth(), getDatePicker().getDayOfMonth());
        int selectedDayIndex = calendar.get(Calendar.DAY_OF_WEEK) - 2; // Adjust for Monday=0
        if (selectedDayIndex < 0) selectedDayIndex = 6; // Sunday
        String selectedDay = DAYS_OF_WEEK[selectedDayIndex];
        int targetDayIndex = Arrays.asList(getDaysOfWeek()).indexOf(targetDayOfWeek);

        Log.d(TAG, "restrictToDayOfWeek: selectedDay=" + selectedDay + ", targetDay=" + targetDayOfWeek);

        if (targetDayIndex != -1 && !selectedDay.equals(targetDayOfWeek)) {
            // Adjust to the nearest valid date
            int daysToAdd = (targetDayIndex - selectedDayIndex + 7) % 7;
            if (daysToAdd == 0) daysToAdd = 7;
            calendar.add(Calendar.DAY_OF_MONTH, daysToAdd);
            // Ensure the adjusted date is not in the past
            Calendar today = Calendar.getInstance();
            if (calendar.before(today)) {
                calendar.add(Calendar.DAY_OF_MONTH, 7); // Move to next valid week
            }
            getDatePicker().updateDate(
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
        }

        // Restrict future selections
        getDatePicker().setOnDateChangedListener((view, year, monthOfYear, dayOfMonth) -> {
            Calendar newDate = Calendar.getInstance();
            newDate.set(year, monthOfYear, dayOfMonth);
            int newDayIndex = newDate.get(Calendar.DAY_OF_WEEK) - 2;
            if (newDayIndex < 0) newDayIndex = 6;
            if (!DAYS_OF_WEEK[newDayIndex].equals(targetDayOfWeek)) {
                int daysToAdd = (Arrays.asList(getDaysOfWeek()).indexOf(targetDayOfWeek) - newDayIndex + 7) % 7;
                if (daysToAdd == 0) daysToAdd = 7;
                newDate.add(Calendar.DAY_OF_MONTH, daysToAdd);
                // Ensure the adjusted date is not in the past
                Calendar today = Calendar.getInstance();
                if (newDate.before(today)) {
                    newDate.add(Calendar.DAY_OF_MONTH, 7); // Move to next valid week
                }
                view.updateDate(
                        newDate.get(Calendar.YEAR),
                        newDate.get(Calendar.MONTH),
                        newDate.get(Calendar.DAY_OF_MONTH)
                );
            }
        });
    }

    // Public getter for DAYS_OF_WEEK
    public static String[] getDaysOfWeek() {
        return DAYS_OF_WEEK;
    }
}