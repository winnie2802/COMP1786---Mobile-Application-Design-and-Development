package com.example.universalyogaadminapp;

public class Schedule {
    private long id;
    private String date;
    private String teacher;
    private String comments;

    // Required for Firebase deserialization
    public Schedule() {
    }

    public Schedule(String date, String teacher, String comments) {
        this.id = -1; // Default, set when retrieved from database
        this.date = date;
        this.teacher = teacher;
        this.comments = comments;
    }

    public Schedule(long id, String date, String teacher, String comments) {
        this.id = id;
        this.date = date;
        this.teacher = teacher;
        this.comments = comments;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}