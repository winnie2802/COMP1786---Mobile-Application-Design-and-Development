package com.example.universalyogaadminapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class SchedulesManagementActivity extends AppCompatActivity implements ScheduleAdapter.OnScheduleActionListener {
    private static final String TAG = "SchedulesManagement";
    private static final int REQUEST_ADD_SCHEDULE = 1;
    private static final int REQUEST_EDIT_SCHEDULE = 2;
    private List<Schedule> scheduleList;
    private ScheduleAdapter scheduleAdapter;
    private long classId;
    private String dayOfWeek;
    private YogaDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedules_management);

        // Initialize database helper
        dbHelper = new YogaDatabaseHelper(this);

        // Get class ID and day of week
        Intent intent = getIntent();
        classId = intent.getLongExtra("classId", -1);
        dayOfWeek = intent.getStringExtra("dayOfWeek");

        Log.d(TAG, "Received: classId=" + classId + ", dayOfWeek=" + dayOfWeek);

        if (classId == -1) {
            Toast.makeText(this, "Invalid class ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Schedules Management");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Initialize schedule list and RecyclerView
        scheduleList = new ArrayList<>();
        scheduleList.addAll(dbHelper.getSchedulesForClass(classId)); // Load from database
        RecyclerView recyclerViewSchedules = findViewById(R.id.recyclerViewSchedules);
        recyclerViewSchedules.setLayoutManager(new LinearLayoutManager(this));
        scheduleAdapter = new ScheduleAdapter(scheduleList, this);
        recyclerViewSchedules.setAdapter(scheduleAdapter);

        // Set up Add Schedule Button
        findViewById(R.id.btnAddSchedule).setOnClickListener(v -> {
            Intent addIntent = new Intent(SchedulesManagementActivity.this, AddScheduleActivity.class);
            addIntent.putExtra("dayOfWeek", dayOfWeek);
            startActivityForResult(addIntent, REQUEST_ADD_SCHEDULE);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == REQUEST_ADD_SCHEDULE) {
                String date = data.getStringExtra("date");
                String teacher = data.getStringExtra("teacher");
                String comments = data.getStringExtra("comments");

                Log.d(TAG, "Add schedule: date=" + date + ", teacher=" + teacher + ", comments=" + comments);

                Schedule schedule = new Schedule(date, teacher, comments);
                dbHelper.addSchedule(classId, schedule); // Save to database and Firebase
                scheduleList.clear();
                scheduleList.addAll(dbHelper.getSchedulesForClass(classId));
                scheduleAdapter.notifyDataSetChanged();
            } else if (requestCode == REQUEST_EDIT_SCHEDULE) {
                int position = data.getIntExtra("schedulePosition", -1);
                Log.d(TAG, "Edit schedule: position=" + position);
                if (position >= 0 && position < scheduleList.size()) {
                    String date = data.getStringExtra("date");
                    String teacher = data.getStringExtra("teacher");
                    String comments = data.getStringExtra("comments");

                    Log.d(TAG, "Edit data: date=" + date + ", teacher=" + teacher + ", comments=" + comments);

                    Schedule updatedSchedule = new Schedule(date, teacher, comments);
                    long scheduleId = scheduleList.get(position).getId();
                    Log.d(TAG, "Schedule ID: " + scheduleId);
                    if (scheduleId != -1) {
                        dbHelper.updateSchedule(scheduleId, updatedSchedule); // Update in database and Firebase
                        scheduleList.clear();
                        scheduleList.addAll(dbHelper.getSchedulesForClass(classId));
                        scheduleAdapter.notifyDataSetChanged();
                        Log.d(TAG, "Schedule updated successfully");
                    } else {
                        Toast.makeText(this, "Failed to find schedule ID", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "Invalid schedule ID");
                    }
                } else {
                    Toast.makeText(this, "Invalid schedule position", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Invalid position: " + position);
                }
            }
        } else {
            Log.w(TAG, "onActivityResult: resultCode=" + resultCode + ", data=" + (data == null ? "null" : "not null"));
        }
    }

    @Override
    public void onEdit(int position) {
        Schedule schedule = scheduleList.get(position);
        Log.d(TAG, "Edit clicked: position=" + position + ", schedule=" + schedule.getDate());
        Intent intent = new Intent(this, EditScheduleActivity.class);
        intent.putExtra("schedulePosition", position);
        intent.putExtra("date", schedule.getDate());
        intent.putExtra("teacher", schedule.getTeacher());
        intent.putExtra("comments", schedule.getComments());
        intent.putExtra("dayOfWeek", dayOfWeek);
        startActivityForResult(intent, REQUEST_EDIT_SCHEDULE);
    }

    @Override
    public void onDelete(int position) {
        // Show confirmation dialog
        new AlertDialog.Builder(this)
                .setTitle("Delete Schedule")
                .setMessage("Are you sure you want to delete this schedule?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    Schedule schedule = scheduleList.get(position);
                    long scheduleId = schedule.getId();
                    Log.d(TAG, "Delete confirmed: position=" + position + ", scheduleId=" + scheduleId);
                    if (scheduleId != -1) {
                        dbHelper.deleteSchedule(scheduleId); // Delete from database and Firebase
                        scheduleList.clear();
                        scheduleList.addAll(dbHelper.getSchedulesForClass(classId));
                        scheduleAdapter.notifyDataSetChanged();
                        Toast.makeText(this, "Schedule deleted successfully", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "Schedule deleted successfully");
                    } else {
                        Toast.makeText(this, "Failed to find schedule ID", Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "Invalid schedule ID");
                    }
                })
                .setNegativeButton("No", (dialog, which) -> {
                    Log.d(TAG, "Delete cancelled");
                    dialog.dismiss();
                })
                .setCancelable(true)
                .show();
    }
}