package com.example.universalyogaadminapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SearchActivity extends AppCompatActivity implements ClassAdapter.OnClassActionListener {
    private EditText editTextTeacherName, editTextDate;
    private Spinner spinnerDayOfWeek, spinnerSearchType;
    private RecyclerView recyclerViewResults;
    private ClassAdapter classAdapter;
    private List<YogaClass> searchResults;
    private YogaDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        dbHelper = new YogaDatabaseHelper(this);

        // Set up Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Search Classes");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Initialize UI elements
        editTextTeacherName = findViewById(R.id.editTextTeacherName);
        editTextDate = findViewById(R.id.editTextDate);
        spinnerDayOfWeek = findViewById(R.id.spinnerDayOfWeek);
        spinnerSearchType = findViewById(R.id.spinnerSearchType);
        recyclerViewResults = findViewById(R.id.recyclerViewResults);
        Button btnSearch = findViewById(R.id.btnSearch);

        // Set up Search Type Spinner
        ArrayAdapter<CharSequence> searchTypeAdapter = ArrayAdapter.createFromResource(
                this, R.array.search_types, android.R.layout.simple_spinner_item);
        searchTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSearchType.setAdapter(searchTypeAdapter);

        // Set up Day of the Week Spinner
        ArrayAdapter<CharSequence> dayAdapter = ArrayAdapter.createFromResource(
                this, R.array.days_of_week, android.R.layout.simple_spinner_item);
        dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDayOfWeek.setAdapter(dayAdapter);

        // Set up Date Picker
        editTextDate.setKeyListener(null);
        editTextDate.setOnClickListener(v -> showDatePickerDialog());
        editTextDate.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) showDatePickerDialog();
        });

        // Set up RecyclerView
        searchResults = new ArrayList<>();
        recyclerViewResults.setLayoutManager(new LinearLayoutManager(this));
        classAdapter = new ClassAdapter(searchResults, this);
        recyclerViewResults.setAdapter(classAdapter);

        // Search button click
        btnSearch.setOnClickListener(v -> performSearch());
    }

    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(selectedYear, selectedMonth, selectedDay);
                    String date = DateFormat.format("dd/MM/yyyy", selectedDate).toString();
                    editTextDate.setText(date);
                },
                year, month, day);
        datePickerDialog.show();
    }

    private void performSearch() {
        String searchType = spinnerSearchType.getSelectedItem() != null ?
                spinnerSearchType.getSelectedItem().toString() : "";
        searchResults.clear();

        if (searchType.equals("Teacher Name")) {
            String teacherName = editTextTeacherName.getText().toString().trim();
            if (teacherName.isEmpty()) {
                Toast.makeText(this, "Please enter a teacher name", Toast.LENGTH_SHORT).show();
                return;
            }
            searchResults.addAll(dbHelper.searchClassesByTeacher(teacherName));
        } else if (searchType.equals("Day of the Week")) {
            String dayOfWeek = spinnerDayOfWeek.getSelectedItem() != null ?
                    spinnerDayOfWeek.getSelectedItem().toString() : "";
            if (dayOfWeek.isEmpty()) {
                Toast.makeText(this, "Please select a day of the week", Toast.LENGTH_SHORT).show();
                return;
            }
            searchResults.addAll(dbHelper.searchClassesByDayOfWeek(dayOfWeek));
        } else if (searchType.equals("Date")) {
            String date = editTextDate.getText().toString().trim();
            if (date.isEmpty()) {
                Toast.makeText(this, "Please select a date", Toast.LENGTH_SHORT).show();
                return;
            }
            searchResults.addAll(dbHelper.searchClassesByDate(date));
        }

        classAdapter.notifyDataSetChanged();
        if (searchResults.isEmpty()) {
            Toast.makeText(this, "No classes found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onEdit(int position) {
        // Not implemented for search results
    }

    @Override
    public void onDelete(int position) {
        // Not implemented for search results
    }

    @Override
    public void onShowSchedules(int position) {
        YogaClass yogaClass = searchResults.get(position);
        long classId = dbHelper.getClassIdByPosition(position); // Simplified; may need adjustment
        List<Schedule> schedules = dbHelper.getSchedulesForClass(classId);

        // Create a dialog or new activity to show details
        Intent intent = new Intent(this, ClassDetailsActivity.class);
        intent.putExtra("dayOfWeek", yogaClass.getDayOfWeek());
        intent.putExtra("timeOfCourse", yogaClass.getTimeOfCourse());
        intent.putExtra("capacity", yogaClass.getCapacity());
        intent.putExtra("duration", yogaClass.getDuration());
        intent.putExtra("price", yogaClass.getPrice());
        intent.putExtra("description", yogaClass.getDescription());
        intent.putStringArrayListExtra("schedules", formatSchedules(schedules));
        startActivity(intent);
    }

    private ArrayList<String> formatSchedules(List<Schedule> schedules) {
        ArrayList<String> scheduleStrings = new ArrayList<>();
        for (Schedule schedule : schedules) {
            scheduleStrings.add("Date: " + schedule.getDate() + "\n" + "Teacher: " + schedule.getTeacher() + "\n" +
                    "Comments: " + (schedule.getComments().isEmpty() ? "None" : schedule.getComments()));
        }
        return scheduleStrings;
    }
}